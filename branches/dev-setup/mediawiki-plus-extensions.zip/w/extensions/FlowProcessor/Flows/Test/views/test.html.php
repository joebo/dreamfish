<h1>HELLO WORLD!</h1>
<?php echo $name?>