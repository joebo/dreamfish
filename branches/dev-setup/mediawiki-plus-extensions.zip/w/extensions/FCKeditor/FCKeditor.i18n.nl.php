<?php

$messages = array(
	'textrichditor' => 'Uitgebreide editor',
	'tog-riched_disable' => 'Uitgebreide editor uitschakelen',
	'tog-riched_disable_ns_main' => 'Uitgebreide editor uitschakelen binnen de hoofdnaamruimte',
	'tog-riched_disable_ns_talk' => 'Uitgebreide editor uitschakelen binnen de naamruimte "{{ns:Talk}}"',
	'tog-riched_disable_ns_user' => 'Uitgebreide editor uitschakelen binnen de naamruimte "{{ns:User}}"',
	'tog-riched_disable_ns_user_talk' => 'Uitgebreide editor uitschakelen binnen de naamruimte "{{ns:User_talk}}"',
	'tog-riched_disable_ns_project' => 'Uitgebreide editor uitschakelen binnen de naamruimte "{{ns:Project}}"',
	'tog-riched_disable_ns_project_talk' => 'Uitgebreide editor uitschakelen binnen de naamruimte "{{ns:Project_talk}}"',
	'tog-riched_disable_ns_image' => 'Uitgebreide editor uitschakelen binnen de naamruimte "{{ns:Image}}"',
	'tog-riched_disable_ns_image_talk' => 'Uitgebreide editor uitschakelen binnen de naamruimte "{{ns:Image_talk}}"',
	'tog-riched_disable_ns_mediawiki' => 'Uitgebreide editor uitschakelen binnen de naamruimte "{{ns:MediaWiki}}"',
	'tog-riched_disable_ns_mediawiki_talk' => 'Uitgebreide editor uitschakelen binnen de naamruimte "{{ns:MediaWiki_talk}}"',
	'tog-riched_disable_ns_template' => 'Uitgebreide editor uitschakelen binnen de naamruimte "{{ns:Template}}"',
	'tog-riched_disable_ns_template_talk' => 'Uitgebreide editor uitschakelen binnen de naamruimte "{{ns:Template_talk}}"',
	'tog-riched_disable_ns_help' => 'Uitgebreide editor uitschakelen binnen de naamruimte "{{ns:Help}}"',
	'tog-riched_disable_ns_help_talk' => 'Uitgebreide editor uitschakelen binnen de naamruimte "{{ns:Help_talk}}"',
	'tog-riched_disable_ns_category' => 'Uitgebreide editor uitschakelen binnen de naamruimte "{{ns:Category}}"',
	'tog-riched_disable_ns_category_talk' => 'Uitgebreide editor uitschakelen binnen de naamruimte "{{ns:Category_talk}}"',
);
