<?php

$messages = array(
	'textrichditor' => 'Editor svicio',
	'tog-riched_disable' => 'Disabilité l\'editor svicio',
	'tog-riched_disable_ns_main' => 'Disabilité l\'editor svicio ant lë spassi nominal prinsipal',
	'tog-riched_disable_ns_talk' => 'Disabilité l\'editor svicio ant lë spassi nominal "{{ns:Talk}}"',
	'tog-riched_disable_ns_user' => 'Disabilité l\'editor svicio ant lë spassi nominal "{{ns:User}}"',
	'tog-riched_disable_ns_user_talk' => 'Disabilité l\'editor svicio ant lë spassi nominal "{{ns:User_talk}}"',
	'tog-riched_disable_ns_project' => 'Disabilité l\'editor svicio ant lë spassi nominal "{{ns:Project}}"',
	'tog-riched_disable_ns_project_talk' => 'Disabilité l\'editor svicio ant lë spassi nominal "{{ns:Project_talk}}"',
	'tog-riched_disable_ns_image' => 'Disabilité l\'editor svicio ant lë spassi nominal "{{ns:Image}}"',
	'tog-riched_disable_ns_image_talk' => 'Disabilité l\'editor svicio ant lë spassi nominal "{{ns:Image_talk}}"',
	'tog-riched_disable_ns_mediawiki' => 'Disabilité l\'editor svicio ant lë spassi nominal "{{ns:MediaWiki}}"',
	'tog-riched_disable_ns_mediawiki_talk' => 'Disabilité l\'editor svicio ant lë spassi nominal "{{ns:MediaWiki_talk}}"',
	'tog-riched_disable_ns_template' => 'Disabilité l\'editor svicio ant lë spassi nominal "{{ns:Template}}"',
	'tog-riched_disable_ns_template_talk' => 'Disabilité l\'editor svicio ant lë spassi nominal "{{ns:Template_talk}}"',
	'tog-riched_disable_ns_help' => 'Disabilité l\'editor svicio ant lë spassi nominal "{{ns:Help}}"',
	'tog-riched_disable_ns_help_talk' => 'Disabilité l\'editor svicio ant lë spassi nominal "{{ns:Help_talk}}"',
	'tog-riched_disable_ns_category' => 'Disabilité l\'editor svicio ant lë spassi nominal "{{ns:Category}}"',
	'tog-riched_disable_ns_category_talk' => 'Disabilité l\'editor svicio ant lë spassi nominal "{{ns:Category_talk}}"',
);
