<?php
$messages = array(
	'textrichditor' => 'Rik tekstredigering',
	'tog-riched_disable' => 'Slå av rik tekstredigering',
	'tog-riched_disable_ns_main' => 'Slå av rik tekstredigering i hovednavnerommet',
	'tog-riched_disable_ns_talk' => 'Slå av rik tekstredigering i «{{ns:Talk}}»-navnerommet',
	'tog-riched_disable_ns_user' => 'Slå av rik tekstredigering i «{{ns:User}}»-navnerommet',
	'tog-riched_disable_ns_user_talk' => 'Slå av rik tekstredigering i «{{ns:User_talk}}»-navnerommet',
	'tog-riched_disable_ns_project' => 'Slå av rik tekstredigering i «{{ns:Project}}»-navnerommet',
	'tog-riched_disable_ns_project_talk' => 'Slå av rik tekstredigering i «{{ns:Project_talk}}»-navnerommet',
	'tog-riched_disable_ns_image' => 'Slå av rik tekstredigering i «{{ns:Image}}»-navnerommet',
	'tog-riched_disable_ns_image_talk' => 'Slå av rik tekstredigering i «{{ns:Image_talk}}»-navnerommet',
	'tog-riched_disable_ns_template' => 'Slå av rik tekstredigering i «{{ns:Template}}»-navnerommet',
	'tog-riched_disable_ns_template_talk' => 'Slå av rik tekstredigering i «{{ns:Template_talk}}»-navnerommet',
	'tog-riched_disable_ns_help' => 'Slå av rik tekstredigering i «{{ns:Help}}»-navnerommet',
	'tog-riched_disable_ns_help_talk' => 'Slå av rik tekstredigering i «{{ns:Help_talk}}»-navnerommet',
	'tog-riched_disable_ns_category' => 'Slå av rik tekstredigering i «{{ns:Category}}»-navnerommet',
	'tog-riched_disable_ns_category_talk' => 'Slå av rik tekstredigering i «{{ns:Category_talk}}»-navnerommet',
);
