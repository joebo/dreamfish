﻿<?php
$messages = array(
'textrichditor' => 'ويرايشگر پيشرفته',
'tog-riched_disable' => 'غيرفعال کردن ويرايشگر پيشرفته',
'tog-riched_disable_ns_main' => 'غيرفعال کردن ويرايشگر پيشرفته در فضاي نام اصلي',
'tog-riched_disable_ns_talk' => 'غيرفعال کردن ويرايشگر پيشرفته در فضاي نام "{{ns:Talk}}"',
'tog-riched_disable_ns_user' => 'غيرفعال کردن ويرايشگر پيشرفته در فضاي نام "{{ns:User}}"',
'tog-riched_disable_ns_user_talk' => 'غيرفعال کردن ويرايشگر پيشرفته در فضاي نام "{{ns:User_talk}}"',
'tog-riched_disable_ns_project' => 'غيرفعال کردن ويرايشگر پيشرفته در فضاي نام "{{ns:Project}}"',
'tog-riched_disable_ns_project_talk' => 'غيرفعال کردن ويرايشگر پيشرفته در فضاي نام 
"{{ns:Project_talk}}"',
'tog-riched_disable_ns_image' => 'غيرفعال کردن ويرايشگر پيشرفته در فضاي نام "{{ns:Image}}"',
'tog-riched_disable_ns_image_talk' => 'غيرفعال کردن ويرايشگر پيشرفته در فضاي نام "{{ns:Image_talk}}"',
'tog-riched_disable_ns_mediawiki' => 'غيرفعال کردن ويرايشگر پيشرفته در فضاي نام "{{ns:MediaWiki}}"',
'tog-riched_disable_ns_mediawiki_talk' => 'غيرفعال کردن ويرايشگر پيشرفته در فضاي نام "{{ns:MediaWiki_talk}}"',
'tog-riched_disable_ns_template' => 'غيرفعال کردن ويرايشگر پيشرفته در فضاي نام "{{ns:Template}}"',
'tog-riched_disable_ns_template_talk' => 'غيرفعال کردن ويرايشگر پيشرفته در فضاي نام "{{ns:Template_talk}}"',
'tog-riched_disable_ns_help' => 'غيرفعال کردن ويرايشگر پيشرفته در فضاي نام "{{ns:Help}}"',
'tog-riched_disable_ns_help_talk' => 'غيرفعال کردن ويرايشگر پيشرفته در فضاي نام "{{ns:Help_talk}}"',
'tog-riched_disable_ns_category' => 'غيرفعال کردن ويرايشگر پيشرفته در فضاي نام "{{ns:Category}}"',
'tog-riched_disable_ns_category_talk' => 'غيرفعال کردن ويرايشگر پيشرفته در فضاي نام "{{ns:Category_talk}}"',
);
