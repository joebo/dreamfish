<?php

$messages = array(
	'textrichditor' => '\'\'Rich Editor\'\'',
	'tog-riched_disable' => 'Desactivar \'\'Rich Editor\'\'',
	'tog-riched_disable_ns_main' => 'Desactivar \'\'Rich Editor\'\' dins l\'espaci de noms principal.',
	'tog-riched_disable_ns_talk' => 'Desactivar \'\'Rich Editor\'\' dins l\'espaci de noms \'\'{{ns:Talk}}\'\'.',
	'tog-riched_disable_ns_user' => 'Desactivar \'\'Rich Editor\'\' dins l\'espaci de noms \'\'{{ns:User}}\'\'.',
	'tog-riched_disable_ns_user_talk' => 'Desactivar \'\'Rich Editor\'\' dins l\'espaci de noms \'\'{{ns:User_talk}}\'\'.',
	'tog-riched_disable_ns_project' => 'Desactivar \'\'Rich Editor\'\' dins l\'espaci de noms \'\'{{ns:Project}}\'\'.',
	'tog-riched_disable_ns_project_talk' => 'Desactivar \'\'Rich Editor\'\' dins l\'espaci de noms \'\'{{ns:Project_talk}}\'\'.',
	'tog-riched_disable_ns_image' => 'Desactivar \'\'Rich Editor\'\' dins l\'espaci de noms \'\'{{ns:Image}}\'\'.',
	'tog-riched_disable_ns_image_talk' => 'Desactivar \'\'Rich Editor\'\' dins l\'espaci de noms \'\'{{ns:Image_talk}}\'\'.',
	'tog-riched_disable_ns_mediawiki' => 'Desactivar \'\'Rich Editor\'\' dins l\'espaci de noms \'\'{{ns:Image_talk}}\'\'.',
	'tog-riched_disable_ns_mediawiki_talk' => 'Desactivar \'\'Rich Editor\'\' dins l\'espaci de noms \'\'{{ns:MediaWiki_talk}}\'\'.',
	'tog-riched_disable_ns_template' => 'Desactivar \'\'Rich Editor\'\' dins l\'espaci de noms \'\'{{ns:Template}}\'\'.',
	'tog-riched_disable_ns_template_talk' => 'Desactivar \'\'Rich Editor\'\' dins l\'espaci de noms \'\'{{ns:Template_talk}}\'\'.',
	'tog-riched_disable_ns_help' => 'Desactivar \'\'Rich Editor\'\' dins l\'espaci de noms \'\'{{ns:Help}}\'\'.',
	'tog-riched_disable_ns_help_talk' => 'Desactivar \'\'Rich Editor\'\' dins l\'espaci de noms \'\'{{ns:Help_talk}}\'\'.',
	'tog-riched_disable_ns_category' => 'Desactivar \'\'Rich Editor\'\' dins l\'espaci de noms \'\'{{ns:Category}}\'\'.',
	'tog-riched_disable_ns_category_talk' => 'Desactivar \'\'Rich Editor\'\' dins l\'espaci de noms \'\'{{ns:Category_talk}}\'\'.',
);
