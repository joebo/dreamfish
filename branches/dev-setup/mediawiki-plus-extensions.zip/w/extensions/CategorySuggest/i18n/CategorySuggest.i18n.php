<?php

# Internationalisation file for the AjaxSuggest extension for MediaWiki
/* CategorySuggest Mediawiki Extension
 *
 * @author Andreas Rindler (mediawiki at jenandi dot com)
 * @licence GNU General Public Licence 2.0 or later
 * @description 
 *
*/

$messages['categorysuggest-title']	= 'CATEGORY ASSIGNMENT';
$messages['categorysuggest-subtitle']	= 'Please enter the name of a category for this article.';
$messages['categorysuggest-boxlabel']	= 'Categories';
$messages['categorysuggest-taglabel']	= 'Popular Categories';
?>
